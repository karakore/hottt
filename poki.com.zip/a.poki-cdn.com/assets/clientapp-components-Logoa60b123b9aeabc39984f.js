try {
    let e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
        a = (new e.Error).stack;
    a && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[a] = "21cbdf5e-d262-46ad-ab62-54b8a0bac5a2", e._sentryDebugIdIdentifier = "sentry-dbid-21cbdf5e-d262-46ad-ab62-54b8a0bac5a2")
} catch (e) {}("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
    id: "5b064a568bd31f9f3aa0d473c3211cd56c4698ac"
};
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [2610, 4810, 7603, 7994], {
        17879: (e, a, t) => {
            t.r(a), t.d(a, {
                default: () => i
            });
            t(17402);
            var l = t(40890),
                n = t(18272),
                d = t(95901);

            function i({
                className: e,
                children: a,
                to: t,
                onClick: i,
                target: o,
                title: r,
                rel: s,
                style: f,
                refForwarded: c,
                ariaLabel: u
            }) {
                return "_blank" === o && (s = s ? `noopener ${s}` : "noopener"), (0, d.Y)("a", {
                    className: e,
                    href: t,
                    onClick: e => {
                        i && i(e), !(0, l.xs)(t) || e.defaultPrevented || 0 !== e.button || o || function(e) {
                            return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
                        }(e) || (e.preventDefault(), (0, n.A)().push(t))
                    },
                    rel: s,
                    target: o,
                    title: r,
                    style: f,
                    ref: c,
                    "aria-label": u,
                    children: a
                })
            }
        },
        23030: (e, a, t) => {
            t.r(a), t.d(a, {
                logo: () => l
            });
            var l = "C9JUSu6VaKM5y0Kq4sg2"
        },
        58686: (e, a, t) => {
            t.r(a), t.d(a, {
                default: () => u
            });
            var l = t(78737),
                n = t(34164),
                d = t(91833),
                i = t(17879),
                o = t(90385),
                r = t(46493),
                s = t(23030),
                f = t(97454),
                c = t(95901);
            const u = function({
                className: e,
                external: a = !1,
                favicon: t = !1,
                to: u,
                title: b,
                ariaLabel: g = "Poki"
            }) {
                const h = (0, l.d4)(o.K5),
                    y = (0, l.d4)(f.Lb),
                    _ = () => {
                        (0, r.F)({
                            category: "logo",
                            action: "click",
                            label: h,
                            data: {
                                path: u
                            },
                            options: {
                                interaction: !0
                            }
                        })
                    };
                let p = t ? (0, c.Y)(d.default, {
                    name: "fav",
                    height: "36",
                    width: "36"
                }) : (0, c.Y)(d.default, {
                    name: "poki",
                    width: "100%",
                    height: "100%"
                });
                if (y) {
                    const e = y.url;
                    p = (0, c.Y)("img", {
                        src: e,
                        alt: "Poki",
                        style: y.style
                    })
                }
                const w = (0, n.A)(s.logo, e);
                return u ? (0, c.Y)(i.default, {
                    className: w,
                    to: u,
                    target: a ? "_blank" : void 0,
                    title: b,
                    onClick: _,
                    ariaLabel: g,
                    children: p
                }) : (0, c.Y)("span", {
                    className: w,
                    children: p
                })
            }
        },
        91833: (e, a, t) => {
            t.r(a), t.d(a, {
                default: () => n
            });
            var l = t(95901);

            function n({
                className: e,
                name: a,
                width: t,
                height: n
            }) {
                return (0, l.Y)("svg", {
                    className: e,
                    width: t,
                    height: n,
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, l.Y)("use", {
                        xlinkHref: `#${a}Icon`
                    })
                })
            }
        }
    }
]);
//# sourceMappingURL=client~app-components-Logo~a60b123b9aeabc39984f.js.map