try {
    let e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
        t = (new e.Error).stack;
    t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "ffd59bfd-a8a1-4333-be7e-9c459581fbe3", e._sentryDebugIdIdentifier = "sentry-dbid-ffd59bfd-a8a1-4333-be7e-9c459581fbe3")
} catch (e) {}("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
    id: "5b064a568bd31f9f3aa0d473c3211cd56c4698ac"
};
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [2610, 4810, 5996, 8551], {
        17879: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => l
            });
            n(17402);
            var a = n(40890),
                s = n(18272),
                o = n(95901);

            function l({
                className: e,
                children: t,
                to: n,
                onClick: l,
                target: r,
                title: i,
                rel: d,
                style: c,
                refForwarded: u,
                ariaLabel: f
            }) {
                return "_blank" === r && (d = d ? `noopener ${d}` : "noopener"), (0, o.Y)("a", {
                    className: e,
                    href: n,
                    onClick: e => {
                        l && l(e), !(0, a.xs)(n) || e.defaultPrevented || 0 !== e.button || r || function(e) {
                            return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
                        }(e) || (e.preventDefault(), (0, s.A)().push(n))
                    },
                    rel: d,
                    target: r,
                    title: i,
                    style: c,
                    ref: u,
                    "aria-label": f,
                    children: t
                })
            }
        },
        55929: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => y
            });
            var a = n(78737),
                s = n(57225),
                o = n(34164),
                l = n(91833),
                r = n(17879),
                i = n(822),
                d = n(89385),
                c = n(98708),
                u = n(88421),
                f = n(11436),
                _ = n(46493),
                h = n(99668),
                b = n(95901);
            const v = (0, s.Ay)({
                resolved: {},
                chunkName: () => "app-components-NavButtonProfile-tsx",
                isReady(e) {
                    const t = this.resolve(e);
                    return !0 === this.resolved[t] && !!n.m[t]
                },
                importAsync: () => n.e(8704).then(n.bind(n, 73757)),
                requireAsync(e) {
                    const t = this.resolve(e);
                    return this.resolved[t] = !1, this.importAsync(e).then((e => (this.resolved[t] = !0, e)))
                },
                requireSync(e) {
                    const t = this.resolve(e);
                    return n(t)
                },
                resolve: () => 73757
            });

            function y() {
                const e = (0, a.wA)(),
                    t = (0, a.d4)(d.Jk),
                    n = (0, a.d4)(f.Pn),
                    s = (0, a.d4)(u.GO),
                    y = (0, a.d4)(c.K);
                return (0, b.FD)("div", {
                    className: h.navButtons,
                    children: [!t && (0, b.Y)(r.default, {
                        className: (0, o.A)(h.navButtons__btn, h.navButtons__btn_left),
                        to: n,
                        onClick: () => (0, _.F)({
                            category: "home",
                            action: "click"
                        }),
                        title: y.home_icon_alt_text,
                        ariaLabel: y.home_icon_alt_text,
                        children: (0, b.Y)(l.default, {
                            name: "home",
                            className: h.navButtons__homeSVGIcon
                        })
                    }), t && (0, b.Y)(v, {
                        className: h.navButtons__btn
                    }), (0, b.FD)("button", {
                        onClick: () => {
                            e(s ? (0, i.QL)() : (0, i.rf)())
                        },
                        type: "button",
                        className: (0, o.A)("buttonReset", h.navButtons__btn, h.navButtons__btn_right),
                        title: y.search_short,
                        "aria-label": y.search_short,
                        children: [y.search, (0, b.Y)(l.default, {
                            name: "search",
                            className: h.navButtons__lookingGlassSVGIcon
                        })]
                    })]
                })
            }
        },
        91833: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => s
            });
            var a = n(95901);

            function s({
                className: e,
                name: t,
                width: n,
                height: s
            }) {
                return (0, a.Y)("svg", {
                    className: e,
                    width: n,
                    height: s,
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, a.Y)("use", {
                        xlinkHref: `#${t}Icon`
                    })
                })
            }
        },
        99668: (e, t, n) => {
            n.r(t), n.d(t, {
                navButtons: () => a,
                navButtons__btn: () => s,
                navButtons__btn_left: () => o,
                navButtons__btn_right: () => l,
                navButtons__homeSVGIcon: () => r,
                navButtons__lookingGlassSVGIcon: () => i
            });
            var a = "NuKVRCDKjJRkfpgoOKXi",
                s = "Ms6HEJ826qeso4NBVCoW",
                o = "uYSe40aoLoVVar9d0u6H",
                l = "pMuUqYFsIC6GCbPomoSK",
                r = "aprWdaSScyiJf4Jvmsx9",
                i = "B_5ykBA46kDOxiz_R9wm"
        }
    }
]);
//# sourceMappingURL=client~app-components-NavButtons~58f229dab71ca3cdca56.js.map