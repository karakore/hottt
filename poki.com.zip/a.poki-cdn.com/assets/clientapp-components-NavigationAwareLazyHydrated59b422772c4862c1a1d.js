try {
    let e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
        d = (new e.Error).stack;
    d && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[d] = "3f5216d7-ad8b-4f58-a2dd-972ce5ef3e98", e._sentryDebugIdIdentifier = "sentry-dbid-3f5216d7-ad8b-4f58-a2dd-972ce5ef3e98")
} catch (e) {}("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
    id: "5b064a568bd31f9f3aa0d473c3211cd56c4698ac"
};
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [4741], {
        25144: (e, d, n) => {
            n.r(d), n.d(d, {
                default: () => a
            });
            var f = n(78737),
                l = n(43882),
                i = n(11436),
                o = n(90385),
                s = n(95901);

            function a({
                ssrOnly: e,
                whenIdle: d,
                whenVisible: n,
                noWrapper: a,
                on: r,
                children: t
            }) {
                const b = (0, f.d4)(i.E6),
                    _ = (0, f.d4)(o.Xk);
                return "POP" !== b || _ ? (0, s.Y)(l.A, {
                    ssrOnly: e,
                    whenIdle: d,
                    whenVisible: n,
                    noWrapper: a,
                    on: r,
                    children: t
                }) : t
            }
        }
    }
]);
//# sourceMappingURL=client~app-components-NavigationAwareLazyHydrate~d59b422772c4862c1a1d.js.map