! function() {
    function e(e, t) {
        fetch(e, {
            method: "POST",
            headers: {
                "Content-Type": "text/plain"
            },
            body: t,
            mode: "no-cors",
            keepalive: !0,
            credentials: "omit"
        }).catch((function(a) {
            console.error(a);
            try {
                var n = "XMLHttpRequest" in window ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                n.open("POST", e, !0), n.setRequestHeader("Content-Type", "text/plain"), n.send(t)
            } catch (e) {}
        }))
    }

    function t(t, a, n) {
        console.error(t);
        var o = [{
            k: "where",
            v: a
        }, {
            k: "error",
            v: t.name && t.message ? "".concat(t.name, ": ").concat(t.message) : JSON.stringify(t)
        }];
        if (void 0 !== n) {
            var i = n;
            "string" != typeof t && (i = JSON.stringify(t)), o.push({
                k: "extra",
                v: i
            })
        }
        e("https://t.poki.io/l", JSON.stringify({
            c: "observer-error",
            ve: 7,
            d: o
        }))
    }
    window._pokiUserGlobalName = window._pokiUserGlobalName || "user";
    var a = "poki_session";
    window._pokiSessionGlobalName = window._pokiSessionGlobalName || "session";
    var n, o = ["poki.at", "poki.be", "poki.by", "poki.ch", "poki.cn", "poki.co.id", "poki.co.il", "poki.com.br", "poki.com", "poki.cz", "poki.de", "poki.dk", "poki.fi", "poki.it", "poki.jp", "poki.nl", "poki.pl", "poki.pt", "poki.se", "www.trochoi.net"];

    function i(e, t) {
        if (!e) return !1;
        if (!(e && e.page && e.landing_page && e.previous_page)) return !1;
        if (!e.tab_id) return !1;
        if (!e.expire || Date.now() > e.expire) return !1;
        if (e.expire > Date.now() + 18e5) return !1;
        if (t) {
            if (void 0 !== e.referrer_domain) {
                var a = function() {
                    try {
                        var e = new URL(document.referrer).hostname;
                        return o.indexOf(e) > -1 ? "poki" : e
                    } catch (e) {}
                    return ""
                }();
                if ("poki" !== a && "authorize.roblox.com" !== a && "accounts.google.com" !== a && a !== e.referrer_domain) return !1
            }
            var n = new URLSearchParams(window.location.search);
            if (["gclid", "msclkid", "yclid", "ttclid", "fbclid", "utm_campaign", "campaign", "adgroup", "creative", "utm_term"].some((function(e) {
                    return n.has(e)
                })) || "web_app_manifest" === n.get("utm_source") || "bing" === n.get("utm_source") || "cpc" === n.get("utm_medium") || "rtb-cpm" === n.get("utm_medium")) return !1
        }
        return !0
    }

    function d() {
        var e = null;
        i(window[window._pokiSessionGlobalName], !1) && (e = window[window._pokiSessionGlobalName]);
        try {
            var n = sessionStorage.getItem(a);
            if (n) {
                var o = JSON.parse(n);
                i(o, !0) && (!e || o.depth > e.depth) && (e = o)
            }
        } catch (e) {
            try {
                t(e, "getSession", sessionStorage.getItem(a))
            } catch (n) {
                t(e, "getSession", n)
            }
        }
        return e
    }

    function r(e) {
        try {
            var n = d();
            if (!n) return;
            e(n);
            var o = JSON.stringify(n);
            try {
                sessionStorage.setItem(a, o)
            } catch (e) {}
            window[window._pokiSessionGlobalName] = n,
                function(e, t) {
                    document.cookie = "".concat(e, "=").concat(t, "; path=/; samesite=lax; max-age=").concat(Math.min(15552e3, 15552e3))
                }(a, o)
        } catch (e) {
            t(e, "updateSessionProperties")
        }
    }
    const l = {};
    if (null !== (n = window) && void 0 !== n && n.visualViewport) {
        const {
            width: e,
            height: t
        } = window.visualViewport;
        l.size = "".concat(Math.round(e), "x").concat(Math.round(t))
    } else {
        var c, u;
        l.size = "".concat(null === (c = window) || void 0 === c ? void 0 : c.innerWidth, "x").concat(null === (u = window) || void 0 === u ? void 0 : u.innerHeight)
    }
    let s = null,
        p = !1;

    function v(e) {
        var t;
        if (s = 0, null != e && null !== (t = e.purpose) && void 0 !== t && t.consents)
            for (let t = 1; t <= 10; t++) e.purpose.consents[t] && (s |= 1 << t)
    }

    function k() {
        window.__tcfapi && !p && (window.__tcfapi("addEventListener", 2, ((e, t) => {
            !t || "tcloaded" !== e.eventStatus && "useractioncomplete" !== e.eventStatus || v(e)
        })), window.__tcfapi("getTCData", 2, ((e, t) => {
            t && v(e)
        })), p = !0)
    }
    k();
    const y = {
        action: "a",
        browser_size: "bs",
        category: "c",
        connect: "co",
        connection_type: "ct",
        count: "cn",
        cpus: "cu",
        data: "d",
        depth: "de",
        dns: "dn",
        dom_complete: "dc",
        domain: "do",
        experiment: "ex",
        first_byte: "fb",
        flash_version: "f",
        game_id: "gid",
        game_version_id: "vid",
        has_adblock: "ha",
        hash: "h",
        id: "id",
        insert_id: "ii",
        interaction: "i",
        is_new: "in",
        key: "k",
        label: "l",
        landing_page: "lp",
        language: "la",
        last_byte: "lb",
        message: "m",
        name: "n",
        nav: "n",
        page: "p",
        pageview_id: "pvid",
        path: "pa",
        previous_page: "pp",
        protocol: "pr",
        query_params: "qp",
        referrer: "r",
        screen_orientation: "sor",
        screen_resolution: "sc",
        scroll_y: "sy",
        session: "s",
        site_id: "si",
        stack: "s",
        tab_id: "ti",
        tag_id: "t",
        tcf_purpose_consents: "tpc",
        time_on_page: "tp",
        time_on_previous_page: "tr",
        time_on_site: "ts",
        time_spa_load: "sl",
        timeout: "to",
        timestamp: "tt",
        timezone: "tz",
        transfer_size: "tr",
        type: "ty",
        user: "u",
        user_id: "ui",
        user_id_version: "uvv",
        user_id_valid_for: "uvi",
        value: "v",
        version: "ve"
    };

    function g(e) {
        return Object.keys(e).forEach((t => {
            if (!y[t]) return console.error("unknown field ".concat(t)), void delete e[t];
            if (Array.isArray(e[t])) {
                if (0 === e[t].length) return void delete e[t];
                for (let a = 0; a < e[t].length; a++) e[t][a] = g(e[t][a])
            } else {
                if (null === e[t] || void 0 === e[t]) return void delete e[t];
                "object" == typeof e[t] && g(e[t])
            }
            const a = y[t];
            t !== a && (e[a] = e[t], delete e[t])
        })), e
    }
    let m = !1;
    const f = ["AT", "BE", "BG", "CH", "CY", "CZ", "DE", "DK", "ES", "EE", "FI", "FR", "GR", "HR", "HU", "IE", "IS", "IT", "LI", "LT", "LU", "LV", "MT", "NL", "NO", "PL", "PT", "RO", "SK", "SI", "SE", "GB"];

    function w(e) {
        m = e
    }

    function b() {
        return (void 0 === window.pokiBingRemarketing || window.pokiBingRemarketing) && (window.pokiCountry && !f.includes(window.pokiCountry) || m)
    }

    function A() {
        return (void 0 === window.pokiGoogleRemarketing || window.pokiGoogleRemarketing) && (window.pokiCountry && !f.includes(window.pokiCountry) || m)
    }
    const h = "AW-962655633";

    function I() {
        if (window.gtagLoaded) return;
        window.gtagLoaded = !0, window.gtag("set", "allow_ad_personalization_signals", !0), window.gtag("set", "restricted_data_processing", !1), window.gtag("set", "linker", {
            accept_incoming: !0
        }), window.gtag("js", new Date);
        const e = A() ? "granted" : "denied";
        window.gtag("consent", "default", {
            ad_storage: e,
            ad_user_data: e,
            ad_personalization: e,
            analytics_storage: e
        }), window.gtag("config", h, {
            send_page_view: !1,
            conversion_linker: !0
        });
        const t = document.createElement("script");
        t.src = "https://www.googletagmanager.com/gtag/js?id=".concat(h);
        const a = document.getElementsByTagName("script")[0];
        a.parentNode.insertBefore(t, a)
    }

    function _(e) {
        I();
        const t = e ? "granted" : "denied";
        window.gtag("consent", "update", {
            ad_storage: t,
            ad_user_data: t,
            ad_personalization: t,
            analytics_storage: t
        })
    }

    function B(e) {
        I(), window.gtag("event", "conversion", {
            send_to: "".concat(h, "/").concat(e),
            value: 1,
            currency: "USD"
        })
    }

    function D() {
        return /(?:phone|windows\s+phone|ipod|blackberry|(?:android|bb\d+|meego|silk|googlebot) .+? mobile|palm|windows\s+ce|opera mini|avantgo|mobilesafari|docomo|kaios)/i.test(navigator.userAgent)
    }

    function S() {
        return /(?:ipad|playbook|(?:android|bb\d+|meego|silk)(?! .+? mobile))/i.test(navigator.userAgent)
    }

    function T() {
        window.uetq || (window.uetq = [], window.uetq.push("config", "tcf", {
            enabled: !0
        }), function(e, t, a, n, o) {
            var i, d, r;
            e[o] = e[o] || [], i = function() {
                var t = {
                    ti: "5066235"
                };
                t.q = e[o], e[o] = new UET(t), e[o].push("pageLoad")
            }, (d = t.createElement(a)).src = "//bat.bing.com/bat.js", d.async = 1, d.onload = d.onreadystatechange = function() {
                var e = this.readyState;
                e && "loaded" !== e && "complete" !== e || (i(), d.onload = d.onreadystatechange = null)
            }, (r = t.getElementsByTagName(a)[0]).parentNode.insertBefore(d, r)
        }(window, document, "script", 0, "uetq"))
    }
    window.gtag_enable_tcf_support = !0, window.dataLayer = window.dataLayer || [], window.gtagLoaded = !1, window.gtag = function() {
        dataLayer.push(arguments)
    };
    const N = 9e5;
    let C, P;

    function E(e) {
        const t = d();
        if (!t) return;
        C = performance.now(), P && clearInterval(P);
        const a = t.gameplayTotalTime || 0;
        a <= N && (P = setTimeout((() => {
            if (t.gclid && A() && (D() ? B("1RivCPGb38gBEJHrg8sD") : S() ? B("nA26CIzb3qQBEJHrg8sD") : B("Q-g4CKu_36QBEJHrg8sD")), b()) {
                T();
                let t = "desktop";
                D() ? t = "mobile" : S() && (t = "tablet");
                let a = !1;
                window.api && window.api.getAdblock && (a = window.api.getAdblock()), window.uetq.push("event", "15-minute-play-time", {
                    event_category: t,
                    event_label: e,
                    event_value: a ? 1 : 0
                })
            }
        }), N - a))
    }

    function M() {
        C && (r((e => {
            e.gameplayTotalTime = (e.gameplayTotalTime || 0) + (performance.now() - C)
        })), C = void 0), P && clearInterval(P)
    }
    window._pokiContextGlobalName = window._pokiContextGlobalName || "context";
    let R = !0;

    function H(e) {
        return "object" != typeof e ? [{
            key: "arg",
            value: JSON.stringify(e)
        }] : Object.keys(e).map((t => {
            if ("category" === t || "action" === t || "label" === t || "eventNoun" === t || "eventVerb" === t) return !1;
            let a = e[t];
            return "object" == typeof a && (a = JSON.stringify(a)), {
                key: t,
                value: a
            }
        })).filter((e => !!e))
    }

    function G(e) {
        const {
            position: t
        } = e.content.data;
        switch (t) {
            case "PP":
                return "preroll";
            case "PM":
                return "midroll";
            case "PR":
                return "rewarded";
            default:
                return "unknown-".concat(t)
        }
    }

    function L(e) {
        return e < 0 ? 0 : e < 30 ? Math.floor(e) : e < 60 ? 30 : e < 120 ? 60 : e < 300 ? 120 : e < 600 ? 300 : e < 1200 ? 600 : e < 1800 ? 1200 : 1800
    }
    window.addEventListener("visibilitychange", (() => {
        R = "visible" === document.visibilityState
    }));
    let W = !1;

    function U(e, a, n) {
        var o, i, l, c;
        let u = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "",
            s = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : [],
            p = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : {};
        const v = window[window._pokiContextGlobalName],
            {
                session: k,
                user: y
            } = v;
        if ("pageview" === a && !v.site.id && !window.pokiAllowPageview) return;
        const g = Math.max(Date.now() - k.page.start, 0),
            m = function() {
                try {
                    return !d()
                } catch (e) {
                    return t(e, "isSessionExpired"), !0
                }
            }();
        let f, w = 0;
        ("pageview" !== a || k.depth > 1) && (w = Math.max(Date.now() - k.landing_page.start, 0)), "pageview" === a && k.previous_page.start && (f = k.page.start - k.previous_page.start);
        let b, A = null === (o = e.content) || void 0 === o || null === (o = o.pokifordevs) || void 0 === o ? void 0 : o.game_id,
            h = null === (i = e.content) || void 0 === i || null === (i = i.pokifordevs) || void 0 === i ? void 0 : i.game_version_id;
        A || ({
            gameID: A
        } = e), h || (h = e.gameVersion), v.site.id || "pubhost" !== a || "initialized" !== n ? "pageview" !== a || W || (W = !0, ({
            referrer: b
        } = document), k.referrer && (b = k.referrer)) : ({
            referrer: b
        } = document);
        let I = 0;
        k.expire && (I = Math.ceil((k.expire - Date.now()) / 1e3)), m && "pageview" !== a || (p.interaction && r((function(e) {
            e.expire = Date.now() + 18e5
        })), window[window._pokiTrackerGlobalName].push({
            session: {
                id: k.id,
                depth: k.depth,
                count: k.count
            },
            user: {
                id: y.id,
                is_new: y.is_new,
                user_id_version: y.version,
                user_id_valid_for: y.ttl
            },
            page: {
                path: k.page.path,
                type: k.page.type,
                id: e.storeNoPageID ? void 0 : k.page.id,
                pageview_id: k.page.pageview_id
            },
            previous_page: {
                path: k.previous_page.path,
                type: k.previous_page.type,
                id: k.previous_page.id,
                pageview_id: k.previous_page.pageview_id
            },
            landing_page: {
                path: k.landing_page.path,
                type: k.landing_page.type,
                id: k.landing_page.id,
                pageview_id: k.landing_page.pageview_id
            },
            category: a,
            action: n,
            label: u,
            data: s,
            interaction: p.interaction,
            site_id: v.site.id,
            tag_id: v.tag,
            referrer: b,
            flash_version: v.flashVersion,
            time_on_site: w,
            time_spa_load: e.loadTime,
            time_on_page: g,
            time_on_previous_page: f,
            tab_id: k.tab_id,
            has_adblock: null === (l = window.api) || void 0 === l || null === (c = l.getAdblock) || void 0 === c ? void 0 : c.call(l),
            once_per_pageview: p.once_per_pageview,
            game_id: A || void 0,
            game_version_id: h || void 0,
            experiment: v.experiment,
            timeout: I
        }))
    }

    function x(e) {
        const a = window[window._pokiContextGlobalName],
            {
                event: n
            } = e,
            o = e.eventData || e.data || {};
        try {
            if ("sdk-message" === n)
                if ("pokiTrackingScreenDisplayAdImpression" === o.content.event) U(o, "ad", "displayImpression", o.content.data.platformAd ? "platform" : "ingame", [{
                    key: "opportunityId",
                    value: o.content.data.opportunityId
                }, {
                    key: "adUnitPath",
                    value: o.content.data.adUnitPath
                }, {
                    key: "prebidBid",
                    value: o.content.data.prebidBid
                }, {
                    key: "prebidBidder",
                    value: o.content.data.prebidBidder
                }, {
                    key: "prebidWon",
                    value: o.content.data.prebidWon || o.content.data.preBidWon
                }, {
                    key: "prebidSecondBid",
                    value: o.content.data.prebidSecondBid
                }, {
                    key: "prebidSecondBidder",
                    value: o.content.data.prebidSecondBidder
                }, {
                    key: "dfpIsBackfill",
                    value: o.content.data.dfpIsBackfill
                }, {
                    key: "dfpLineItemId",
                    value: o.content.data.dfpLineItemId
                }, {
                    key: "duringGameplay",
                    value: o.content.data.duringGameplay
                }, {
                    key: "houseAdId",
                    value: o.content.data.houseAdId
                }, {
                    key: "isEmpty",
                    value: o.content.data.isEmpty
                }, {
                    key: "adDomain",
                    value: o.content.data.adDomain
                }, {
                    key: "trigger",
                    value: o.content.data.refreshType
                }, {
                    key: "number",
                    value: o.content.data.refreshNumber
                }, {
                    key: "blocked",
                    value: o.content.data.blocked
                }]);
                else if ("pokiTrackingScreenDisplayAdRequested" === o.content.event) U(o, "ad", "displayRequest", o.content.data.platformAd ? "platform" : "ingame", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adUnitPath",
                value: o.content.data.adUnitPath
            }, {
                key: "duringGameplay",
                value: o.content.data.duringGameplay
            }, {
                key: "trigger",
                value: o.content.data.refreshType
            }, {
                key: "number",
                value: o.content.data.refreshNumber
            }, {
                key: "headerBiddingAllowed",
                value: o.content.data.headerBiddingAllowed
            }]);
            else if ("pokiTrackingScreenDisplayAdDestroy" !== o.content.event || o.content.data.platformAd)
                if ("pokiTrackingScreenDisplayAdDestroy" === o.content.event && o.content.data.platformAd) U(o, "platform", "destroyAd", "", [{
                    key: "opportunityId",
                    value: o.content.data.opportunityId
                }]);
                else if ("pokiTrackingScreenGameLoadingFinished" === o.content.event) U(o, "game", "loadingFinished", "", [{
                key: "time_on_page",
                value: o.content.data.now
            }, {
                key: "transferSize",
                value: o.content.data.transferSize
            }, {
                key: "trackers",
                value: o.content.data.trackers
            }, {
                key: "external_resources",
                value: o.content.data.external_resources
            }], {
                once_per_pageview: !0
            });
            else if ("pokiTrackingScreenGameplayStart" === o.content.event) {
                var i;
                U(o, "game", "play", "start", H(o.content.data), {
                    interaction: !0
                }), E(null === (i = a.page) || void 0 === i || null === (i = i.content) || void 0 === i || null === (i = i.game) || void 0 === i ? void 0 : i.id)
            } else if ("pokiTrackingScreenGameplayStop" === o.content.event) M(), U(o, "game", "play", "stop", H(o.content.data), {
                interaction: !0
            });
            else if ("pokiTrackingAdsStatusError" === o.content.event) U(o, "ad", "error", "", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "waterfall",
                value: o.content.data.waterfall
            }]);
            else if ("pokiTrackingSdkStatusFailed" === o.content.event) U(o, "ad", "failed", "", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }]);
            else if ("pokiTrackingAdsStatusBuffering" === o.content.event) U(o, "ad", "videoBuffering", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }]);
            else if ("pokiTrackingAdsVideoError" === o.content.event) U(o, "ad", "videoError", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "message",
                value: o.content.data.message
            }, {
                key: "errorCode",
                value: o.content.data.errorCode
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }, {
                key: "creativeId",
                value: o.content.data.creativeId
            }, ...1 === o.content.data.waterfall ? [{
                key: "imaAdID",
                value: o.content.data.IMAAdID
            }, {
                key: "imaAdSystem",
                value: o.content.data.IMAAdSystem
            }, {
                key: "imaContentType",
                value: o.content.data.IMAContentType
            }, {
                key: "imaTitle",
                value: o.content.data.IMATitle
            }, {
                key: "imaUniversalAdIDRegistry",
                value: o.content.data.IMAUniversalAdIDRegistry
            }, {
                key: "imaUniversalAdIDValue",
                value: o.content.data.IMAUniversalAdIDValue
            }, {
                key: "imaUniversalAdIDs",
                value: o.content.data.IMAUniversalAdIDs
            }, {
                key: "imaWrapperIDs",
                value: o.content.data.IMAWrapperIDs
            }, {
                key: "hbPrebidLikelyWon",
                value: o.content.data.HBPrebidLikelyWon
            }, {
                key: "hbDetectedWinningBidder",
                value: o.content.data.HBDetectedWinningBidder
            }, {
                key: "hbPrebidWon",
                value: o.content.data.HBPrebidWon
            }, {
                key: "hbAdDomain",
                value: o.content.data.HBAdDomain
            }, {
                key: "hbBidder",
                value: o.content.data.HBBidder
            }, {
                key: "hbSource",
                value: o.content.data.HBSource
            }, {
                key: "hbAdId",
                value: o.content.data.HBAdId
            }, {
                key: "hbCreativeId",
                value: o.content.data.HBCreativeId
            }, {
                key: "apsBidder",
                value: o.content.data.APSBidder
            }] : [], ...o.content.data.HBVastXML ? [{
                key: "hbVastXML",
                value: o.content.data.HBVastXML
            }] : []]);
            else if ("pokiTrackingAdsVideoExtendedVideoError" === o.content.event) U(o, "ad", "videoExtendedError", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "message",
                value: o.content.data.message
            }, {
                key: "errorCode",
                value: o.content.data.errorCode
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }, {
                key: "creativeId",
                value: o.content.data.creativeId
            }, {
                key: "imaAdID",
                value: o.content.data.IMAAdID
            }, {
                key: "imaAdSystem",
                value: o.content.data.IMAAdSystem
            }, {
                key: "imaContentType",
                value: o.content.data.IMAContentType
            }, {
                key: "imaTitle",
                value: o.content.data.IMATitle
            }, {
                key: "imaUniversalAdIDRegistry",
                value: o.content.data.IMAUniversalAdIDRegistry
            }, {
                key: "imaUniversalAdIDValue",
                value: o.content.data.IMAUniversalAdIDValue
            }, {
                key: "imaUniversalAdIDs",
                value: o.content.data.IMAUniversalAdIDs
            }, {
                key: "imaWrapperIDs",
                value: o.content.data.IMAWrapperIDs
            }, {
                key: "hbPrebidLikelyWon",
                value: o.content.data.HBPrebidLikelyWon
            }, {
                key: "hbDetectedWinningBidder",
                value: o.content.data.HBDetectedWinningBidder
            }, {
                key: "hbPrebidWon",
                value: o.content.data.HBPrebidWon
            }, {
                key: "hbAdDomain",
                value: o.content.data.HBAdDomain
            }, {
                key: "hbBidder",
                value: o.content.data.HBBidder
            }, {
                key: "hbSource",
                value: o.content.data.HBSource
            }, {
                key: "hbAdId",
                value: o.content.data.HBAdId
            }, {
                key: "hbCreativeId",
                value: o.content.data.HBCreativeId
            }, {
                key: "apsBidder",
                value: o.content.data.APSBidder
            }, {
                key: "vastChain",
                value: o.content.data.vastChain
            }, {
                key: "vastResolved",
                value: o.content.data.vastResolved
            }, {
                key: "vastResolveErr",
                value: o.content.data.vastResolveErr
            }]);
            else if ("pokiTrackingAdsVideoLoaderError" === o.content.event) U(o, "ad", "videoLoaderError", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }]);
            else if ("pokiTrackingAdsStatusPrebidRequested" === o.content.event) U(o, "ad", "videoPrebidRequested", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "blocked",
                value: o.content.data.blocked
            }]);
            else if ("pokiTrackingAdsStatusReady" === o.content.event) U(o, "ad", "videoReady", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }]);
            else if ("pokiTrackingAdsStatusSkipped" === o.content.event) U(o, "ad", "videoSkipped", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }], {
                interaction: !0
            });
            else if ("pokiTrackingAdsVideoClicked" === o.content.event) U(o, "ad", "videoClicked", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }], {
                interaction: !0
            });
            else if ("pokiTrackingAdsStatusCompleted" === o.content.event) U(o, "ad", "videoCompleted", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }]);
            else if ("pokiTrackingAdsStatusImpression" === o.content.event) {
                U(o, "ad", "videoImpression", G(o), [{
                    key: "waterfall",
                    value: o.content.data.waterfall
                }, {
                    key: "opportunityId",
                    value: o.content.data.opportunityId
                }, {
                    key: "adBreakId",
                    value: o.content.data.adBreakId
                }, {
                    key: "currentAdNumber",
                    value: o.content.data.currentAdNumber
                }, {
                    key: "totalAdAmount",
                    value: o.content.data.totalAdAmount
                }, {
                    key: "prebidBidder",
                    value: o.content.data.prebidBidder
                }, {
                    key: "prebidBid",
                    value: o.content.data.prebidBid
                }, {
                    key: "creativeId",
                    value: o.content.data.creativeId
                }, {
                    key: "adUnitPath",
                    value: o.content.data.adUnitPath
                }, {
                    key: "houseAdId",
                    value: o.content.data.houseAdId
                }, {
                    key: "adDomain",
                    value: o.content.data.adDomain
                }]);
                var d, l;
                if (A()) null === (d = window) || void 0 === d || null === (l = d.gtag) || void 0 === l || l.call(d, "event", "conversion", {
                    send_to: "AW-962655633/FPkKCJ6c7KQBEJHrg8sD",
                    value: 0,
                    currency: "MXN"
                })
            } else if ("pokiTrackingAdsVideoPaused" === o.content.event) U(o, "ad", "videoPaused", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }]);
            else if ("pokiTrackingAdsStatusRequested" === o.content.event) U(o, "ad", "videoRequest", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "adUnitPath",
                value: o.content.data.adUnitPath
            }, {
                key: "headerBiddingAllowed",
                value: o.content.data.headerBiddingAllowed
            }]);
            else if ("pokiTrackingAdsVideoResumed" === o.content.event) U(o, "ad", "videoResumed", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }]);
            else if ("pokiTrackingAdsStatusStarted" === o.content.event) U(o, "ad", "videoStarted", G(o), [{
                key: "waterfall",
                value: o.content.data.waterfall
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }, {
                key: "duration",
                value: o.content.data.duration
            }, {
                key: "skip",
                value: o.content.data.skip
            }, {
                key: "prebidBidder",
                value: o.content.data.prebidBidder
            }, {
                key: "prebidBid",
                value: o.content.data.prebidBid
            }, {
                key: "creativeId",
                value: o.content.data.creativeId
            }, {
                key: "adUnitPath",
                value: o.content.data.adUnitPath
            }, {
                key: "houseAdId",
                value: o.content.data.houseAdId
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }, {
                key: "hbPrebidLikelyWon",
                value: o.content.data.HBPrebidLikelyWon
            }, {
                key: "hbDetectedWinningBidder",
                value: o.content.data.HBDetectedWinningBidder
            }, {
                key: "hbPrebidWon",
                value: o.content.data.HBPrebidWon
            }]);
            else if ("pokiTrackingRewardedWebRequest" === o.content.event) U(o, "ad", "rewardedWeb", "request", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }]);
            else if ("pokiTrackingRewardedWebReady" === o.content.event) U(o, "ad", "rewardedWeb", "ready", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }]);
            else if ("pokiTrackingRewardedWebImpression" === o.content.event) U(o, "ad", "rewardedWeb", "impression", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adUnitPath",
                value: o.content.data.adUnitPath
            }, {
                key: "bid",
                value: o.content.data.bid
            }, {
                key: "bidder",
                value: o.content.data.bidder
            }, {
                key: "prebidBidder",
                value: o.content.data.prebidBidder
            }, {
                key: "prebidWon",
                value: o.content.data.prebidWon || o.content.data.preBidWon
            }, {
                key: "adDomain",
                value: o.content.data.adDomain
            }]);
            else if ("pokiTrackingRewardedWebClosedGranted" === o.content.event) U(o, "ad", "rewardedWeb", "closedGranted", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }]);
            else if ("pokiTrackingRewardedWebClosedDeclined" === o.content.event || "pokiTrackingRewardedWebclosedDeclined" === o.content.event) U(o, "ad", "rewardedWeb", "closedDeclined", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }]);
            else if ("pokiTrackingRewardedWebEmpty" === o.content.event) U(o, "ad", "rewardedWeb", "empty", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }]);
            else if ("pokiTrackingScreenFirstRound" === o.content.event) {
                var c, u;
                const e = A();
                if (U(o, "game", "play", "first", [{
                        key: "hasGoogleConsent",
                        value: e
                    }], {
                        interaction: !0,
                        once_per_pageview: !0
                    }), E(null === (c = a.page) || void 0 === c || null === (c = c.content) || void 0 === c || null === (c = c.game) || void 0 === c ? void 0 : c.id), "GB" === a.geo) return;
                const t = null === (u = a.page) || void 0 === u || null === (u = u.content) || void 0 === u || null === (u = u.game) || void 0 === u ? void 0 : u.id;
                let n = !1;
                if (window.api && window.api.getAdblock && (n = window.api.getAdblock()), b()) {
                    T();
                    let e = "desktop";
                    D() ? e = "mobile" : S() && (e = "tablet"), window.uetq.push("event", "game-play-first", {
                        event_category: e,
                        event_label: t,
                        event_value: n ? 1 : 0
                    }), n || window.uetq.push("event", "", {
                        ecomm_prodid: t,
                        ecomm_pagetype: "product"
                    })
                }
                e && (B("KzjDCPH3l6IBEJHrg8sD"), B("YAozCMbHmZQDEJHrg8sD"), D() ? (B("GcnkCL2-mZQDEJHrg8sD"), B("yoVJCODb6pMDEJHrg8sD")) : S() ? (B("LpAFCNHG6pMDEJHrg8sD"), B("NC5BCKnU6pMDEJHrg8sD")) : (B("tmXGCPitoJQDEJHrg8sD"), B("vjKvCO35q4cDEJHrg8sD"), /^((?!chrome|android).)*safari/i.test(navigator.userAgent) ? B("AT-CCLLI3qQBEJHrg8sD") : B("XuGfCNXE3qQBEJHrg8sD")))
            } else if ("pokiTrackingScreenCommercialBreak" === o.content.event) U(o, "game", "commercialBreak", "", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }]);
            else if ("pokiTrackingScreenRewardedBreak" === o.content.event) U(o, "game", "rewardedBreak", "", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "adBreakId",
                value: o.content.data.adBreakId
            }, {
                key: "currentAdNumber",
                value: o.content.data.currentAdNumber
            }, {
                key: "totalAdAmount",
                value: o.content.data.totalAdAmount
            }].filter((e => void 0 !== e.value)), {
                interaction: !0
            });
            else if ("SaveGameMigrator" === o.type && "error" === o.content.event) U(o, "game", "saveGameMigrator", "error", [{
                key: "error",
                value: o.content.error
            }]);
            else if ("SaveGameMigrator" === o.type && "start" === o.content.event) U(o, "game", "saveGameMigrator", "start");
            else if ("SaveGameMigrator" === o.type && "timeout" === o.content.event) U(o, "game", "saveGameMigrator", "timeout");
            else if ("pokiTrackingSdkStatusInitialized" === o.content.event) U(o, "game", "sdkInitialized");
            else if ("pokiTrackingScreenDisplayAdRequest" !== o.content.event || o.content.data.platformAd)
                if ("pokiTrackingScreenDisplayAdRequest" === o.content.event && o.content.data.platformAd) U(o, "platform", "displayAd", "", [{
                    key: "opportunityId",
                    value: o.content.data.opportunityId
                }, {
                    key: "size",
                    value: o.content.data.size
                }]);
                else if ("pokiTrackingCustom" === o.content.event) U(o, o.content.data.category || o.content.data.eventNoun, o.content.data.action || o.content.data.eventVerb, "", H(o.content.data.eventData || {}));
            else if ("pokiTrackingScreenPlayerActive" === o.content.event) U(o, "game", "playerActive", "", [], {
                interaction: !0
            });
            else if ("pokiTrackingPlaytestShowModal" === o.content.event) U(o, "playtest", "showModal", "", [{
                key: "show",
                value: o.content.data.show
            }]);
            else if ("pokiTrackingPlaytestAccepted" === o.content.event) U(o, "playtest", "accepted", "", [], {
                interaction: !0
            });
            else if ("pokiTrackingPlaytestRejected" === o.content.event) U(o, "playtest", "rejected", "", [], {
                interaction: !0
            });
            else if ("pokiTrackingPlaytestNoCanvas" === o.content.event) U(o, "playtest", "noCanvas", "", []);
            else if ("pokiTrackingPlaytestStarting" === o.content.event) U(o, "playtest", "starting", "", []);
            else if ("pokiTrackingPlaytestClosed" === o.content.event) U(o, "playtest", "closed", "", [{
                key: "reason",
                value: o.content.data.reason
            }]);
            else if ("pokiTrackingPlaytestError" === o.content.event) U(o, "playtest", "error", "", [{
                key: "message",
                value: o.content.data.message
            }]);
            else if ("pokiTrackingAdsAYFailed" === o.content.event) U(o, "ay", "failed", "", [{
                key: "reason",
                value: o.content.data.reason
            }, {
                key: "ayMode",
                value: o.content.data.ayMode
            }, {
                key: "gptRejected",
                value: o.content.data.gptRejected
            }, {
                key: "imaRejected",
                value: o.content.data.imaRejected
            }, {
                key: "prebidRejected",
                value: o.content.data.prebidRejected
            }, {
                key: "a9Rejected",
                value: o.content.data.a9Rejected
            }, {
                key: "displayOnly",
                value: o.content.data.displayOnly
            }, {
                key: "fullStack",
                value: o.content.data.fullStack
            }]);
            else if ("pokiTrackingAdsDebugging" === o.content.event) {
                const {
                    category: e,
                    action: t,
                    label: a,
                    data: n
                } = o.content.data;
                if ("" === e || "" === t) return;
                U(o, e, t, a, [Object.entries(n).map((e => {
                    let [t, a] = e;
                    return {
                        key: t,
                        value: a
                    }
                }))])
            } else "pokiTrackingAdsDisplayNotFilled" === o.content.event && U(o, "ad", "unfilled", "", [{
                key: "bidder",
                value: o.content.data.bidder
            }, {
                key: "cpm",
                value: o.content.data.cpm
            }, {
                key: "adUnitPath",
                value: o.content.data.adUnitPath
            }, {
                key: "opportunityId",
                value: o.content.data.opportunityId
            }]);
            else U(o, "game", "displayAd", "", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }, {
                key: "size",
                value: o.content.data.size
            }]);
            else U(o, "game", "destroyAd", "ingame", [{
                key: "opportunityId",
                value: o.content.data.opportunityId
            }]);
            else if ("adslot-renderEnded" === n) U(o, "ad", "displayImpression", "platform", [{
                key: "trigger",
                value: o.refreshType
            }, {
                key: "adUnitPath",
                value: o.adUnitPath
            }, {
                key: "number",
                value: o.refreshNumber
            }, {
                key: "opportunityId",
                value: o.opportunityId
            }, {
                key: "prebidBid",
                value: o.prebidBid
            }, {
                key: "prebidBidder",
                value: o.prebidBidder
            }, {
                key: "prebidWon",
                value: o.prebidWon || o.preBidWon
            }, {
                key: "prebidSecondBid",
                value: o.prebidSecondBid
            }, {
                key: "prebidSecondBidder",
                value: o.prebidSecondBidder
            }, {
                key: "dfpIsBackfill",
                value: o.dfpIsBackfill
            }, {
                key: "dfpLineItemId",
                value: o.dfpLineItemId
            }, {
                key: "houseAdId",
                value: o.houseAdId
            }, {
                key: "isEmpty",
                value: o.isEmpty
            }, {
                key: "adDomain",
                value: o.adDomain
            }]);
            else if ("ads-adblocked" === n) U(o, "ad", "adblocked");
            else if ("ads-notFound" === n) U(o, "ad", "notFound", "platform", [{
                key: "event",
                value: o.event
            }, {
                key: "code",
                value: o.code
            }, {
                key: "refreshType",
                value: o.refreshType
            }]);
            else if ("ads-render" === n) U(o, "ad", "displayRequest", "platform", [{
                key: "trigger",
                value: o.refreshType
            }, {
                key: "adUnitPath",
                value: o.adUnitPath
            }, {
                key: "number",
                value: o.refreshNumber
            }, {
                key: "opportunityId",
                value: o.opportunityId
            }]);
            else if ("housead-click" === n) U(o, "ad", "houseAdClick", "platform", [{
                key: "houseAdId",
                value: o.houseAdId
            }]);
            else if ("consent-full" === n) w(!0), _(!0), U(o, "consent", "full"),
                function(e) {
                    if ("GB" !== e.geo) {
                        window._comscore = window._comscore || [], window._comscore.push({
                            c1: "2",
                            c2: "20061681"
                        });
                        var t = document.createElement("script");
                        t.src = "https://sb.scorecardresearch.com/cs/20061681/beacon.js";
                        var a = document.getElementsByTagName("script")[0];
                        a.parentNode.insertBefore(t, a)
                    }
                }(a);
            else if ("consent-no" === n) w(!1), _(!1), U(o, "consent", "no");
            else if ("consent-noniab" === n) {
                const {
                    nonIABConsents: e
                } = o;
                U(o, "consent", "noniab", "", [{
                    key: "consents",
                    value: JSON.stringify(e)
                }])
            } else if ("consent-npa" === n) U(o, "consent", "npa");
            else if ("consent-unknown" === n) U(o, "consent", "unknown");
            else if ("consent-bootError" === n) U(o, "consent", "bootError");
            else if (n.startsWith("rating-")) U(o, "game", "rating", n.substr(13).toLowerCase(), [{
                key: "previous_vote",
                value: o.previousVote
            }], {
                interaction: !0
            });
            else if ("sdk-details" === n) U(o, "game", "sdkDetails", "", [{
                key: "version",
                value: o.version
            }], {
                once_per_pageview: !0
            });
            else if ("react-prehydrate" === n) {
                const e = [{
                    key: "bot.verified",
                    value: window.pokiBotVerified
                }, {
                    key: "bot.score",
                    value: window.pokiBotScore
                }, {
                    key: "playground",
                    value: null == o ? void 0 : o.playground
                }, {
                    key: "sdk",
                    value: null == o ? void 0 : o.sdk
                }, {
                    key: "ayMode",
                    value: null == o ? void 0 : o.ayMode
                }, {
                    key: "sessionRandom",
                    value: a.session.random
                }];
                void 0 !== o.isIPad && e.push({
                    key: "isIPad",
                    value: o.isIPad
                });
                const t = () => {
                    U(o, "page", "reactPrehydrate", a.page.type, e)
                };
                try {
                    navigator.cookieDeprecationLabel.getValue().then((t => {
                        t && e.push({
                            key: "cookieDeprecationLabel",
                            value: t
                        })
                    })).finally((() => {
                        t()
                    }))
                } catch (e) {
                    t()
                }
            } else if ("tile-click" === n) o.searchExpanded ? U(o, "search", "tileClick", a.page.type, [{
                key: "id",
                value: o.id
            }, {
                key: "type",
                value: o.type
            }, {
                key: "index",
                value: o.index
            }, {
                key: "path",
                value: o.path
            }, {
                key: "list",
                value: o.list
            }, {
                key: "terms",
                value: o.terms
            }, {
                key: "searchSessionId",
                value: o.searchSessionId
            }, {
                key: "panelSection",
                value: o.panelSection
            }], {
                interaction: !0
            }) : U(o, "page", "tileClick", a.page.type, [{
                key: "id",
                value: o.id
            }, {
                key: "type",
                value: o.type
            }, {
                key: "index",
                value: o.index
            }, {
                key: "path",
                value: o.path
            }, {
                key: "list",
                value: o.list
            }, {
                key: "thumbnail",
                value: o.image
            }], {
                interaction: !0
            });
            else if ("pubHost-initialized" === n) {
                var s, p;
                U(o, "pubhost", "initialized", "", [{
                    key: "topOrigin",
                    value: o.topOrigin
                }, {
                    key: "bot.verified",
                    value: null === (s = o.bot) || void 0 === s ? void 0 : s.verified
                }, {
                    key: "bot.score",
                    value: null === (p = o.bot) || void 0 === p ? void 0 : p.score
                }])
            } else if ("page-pulse" === n) {
                M(), E();
                const e = Math.floor((Date.now() - a.session.page.start) / 1e3),
                    t = function(e) {
                        return L(e)
                    }(e),
                    n = function(e) {
                        return L(e - 30)
                    }(e);
                if ((30 === t && n < 30 || 60 === t && n < 60 || 120 === t && n < 120 || 300 === t && n < 300 || 600 === t && n < 600 || 1200 === t && n < 1200 || 1800 === t && n < 1800) && U(o, "page", "timeSpent", "".concat(t, "s"), [{
                        key: "visible",
                        value: R ? "1" : "0"
                    }]), "GB" === a.geo) return;
                if (e >= 300 && e < 330) {
                    if (b() && "game" === a.page.type) {
                        var v;
                        T();
                        const e = null === (v = a.page) || void 0 === v || null === (v = v.content) || void 0 === v || null === (v = v.game) || void 0 === v ? void 0 : v.id;
                        let t = !1;
                        window.api && window.api.getAdblock && (t = window.api.getAdblock());
                        let n = "desktop";
                        D() ? n = "mobile" : S() && (n = "tablet"), window.uetq.push("event", "page_timeSpent-300", {
                            event_category: n,
                            event_label: e,
                            event_value: t ? 1 : 0
                        })
                    }
                    "game" === a.page.type && A() && (k = a.user.id, y = a.page.id, I(), window.gtag("event", "page_view", {
                        send_to: h,
                        user_id: k,
                        value: 0,
                        items: [{
                            id: y,
                            google_business_vertical: "custom"
                        }]
                    }), B("2IEyCPmFmZQDEJHrg8sD"), D() ? B("AYEACNah6pMDEJHrg8sD") : S() ? B("y05mCNeWmZQDEJHrg8sD") : B("lsPJCLbOqYEBEJHrg8sD"))
                } else e >= 900 && e < 930 && "game" === a.page.type && A() && (D() ? B("t5VrCLXIlMkBEJHrg8sD") : S() ? B("WUfoCMSC5LkBEJHrg8sD") : B("Gh96CL-84MkBEJHrg8sD"))
            } else if ("appStoreButton-click" === n) U(o, "game", "appstoreClick", o.store, [], {
                interaction: !0
            });
            else if ("home-click" === n) U(o, "home", "click", a.page.type, [], {
                interaction: !0
            });
            else if ("logo-click" === n) U(o, "logo", "click", a.page.type, [], {
                interaction: !0
            });
            else if ("fullscreenButton-click" === n) U(o, "fullscreenButton", "click", "", [{
                key: "targetState",
                value: o.targetState
            }], {
                interaction: !0
            });
            else if ("page-pillClick" === n) U(o, "page", "pillClick", "", [], {
                interaction: !0
            });
            else if ("page-pillDrag" === n) U(o, "page", "pillDrag", "", [{
                key: "x",
                value: o.x
            }, {
                key: "y",
                value: o.y
            }], {
                interaction: !0
            });
            else if ("page-autoRedirectClick" === n) U(o, "page", "autoRedirect", "click", [], {
                interaction: !0
            });
            else if ("searchPanel-close" === n) U(o, "searchPanel", "close", a.page.type, [{
                key: "searchSessionId",
                value: o.searchSessionId
            }], {
                interaction: !0
            });
            else if ("searchPanel-open" === n) U(o, "searchPanel", "open", a.page.type, [{
                key: "searchSessionId",
                value: o.searchSessionId
            }], {
                interaction: !0
            });
            else if ("game-launch" === n) U(o, "game", "launch", "", [], {
                interaction: !0
            });
            else if ("page-view" !== n && "pageview" !== n || 0 === o.counter) {
                const {
                    category: t,
                    action: n,
                    options: i
                } = e;
                let {
                    label: d
                } = e;
                null != i && i.pageTypeAsLabel && (d = a.page.type), U(o, t, n, d, H(o), i)
            } else {
                const e = [];
                void 0 === o.counter && window.pokiBotDetected && e.push({
                        key: "bot",
                        value: window.pokiBotDetected
                    }), U(o, "pageview", "", "", e, {
                        interaction: !0
                    }), M(),
                    function(e, t) {
                        const a = new URLSearchParams(t).get(e);
                        return null === a ? "" : a
                    }("gclid", window.location.search) && r((e => {
                        e.gclid = !0
                    }))
            }
        } catch (e) {
            t(e, "gtm")
        }
        var k, y
    }
    const q = window;
    q._pokiTrackerGlobalName = q._pokiTrackerGlobalName || "tracker", q[q._pokiTrackerGlobalName] = q[q._pokiTrackerGlobalName] || [];
    const J = q[q._pokiTrackerGlobalName];
    for (J.uniqueEvents = {}, J.firstPageview = !0, J.installTCFHandler = k, J.push = function(e, a, n, o, i, d) {
            return r => {
                if ("function" != typeof r) try {
                    var l;
                    if (r.version = 7, !r.category) return;
                    if (r.once_per_pageview) {
                        const e = "".concat(r.category, "-").concat(r.action || "", "-").concat(r.label || "");
                        if (a.uniqueEvents[e]) return;
                        a.uniqueEvents[e] = !0
                    }
                    if (delete r.once_per_pageview, "pageview" === r.category && (a.uniqueEvents = {}, r.query_params = e.location.search.substr(1), r.hash = e.location.hash.substr(1)), void 0 !== r.action && null !== r.action && (r.action = r.action.toString()), "" === r.action && delete r.action, void 0 !== r.label && null !== r.label && (r.label = r.label.toString()), "" === r.label && delete r.label, Array.isArray(r.data))
                        for (let e = 0; e < r.data.length; e++) void 0 !== r.data[e].value && null !== r.data[e].value && (r.data[e].value = r.data[e].value.toString());
                    else delete r.data;
                    if (r.cpus = e.navigator.hardwareConcurrency || 0, r.domain = e.location.hostname, r.protocol = e.location.protocol.substr(0, e.location.protocol.length - 1), r.scroll_y = e.scrollY, r.timezone = (new Date).getTimezoneOffset(), r.timestamp = Date.now(), r.tcf_purpose_consents = d(), e.navigator.connection && e.navigator.connection.effectiveType && (r.connection_type = e.navigator.connection.effectiveType), r.user && (r.user.language = e.navigator.language), r.screen_resolution = e.screen.width + "x" + e.screen.height, r.screen_orientation = null === (l = e.screen) || void 0 === l || null === (l = l.orientation) || void 0 === l ? void 0 : l.type, r.browser_size = i.size, "pageview" === r.category && a.firstPageview && e.performance && e.performance.getEntriesByType) try {
                        const t = e.performance.getEntriesByType("navigation");
                        if (t.length > 0) {
                            const e = t[0];
                            r.nav = {
                                connect: Math.round(e.connectEnd - e.connectStart),
                                dns: Math.round(e.domainLookupEnd - e.domainLookupStart),
                                dom_complete: Math.round(e.domComplete),
                                first_byte: Math.round(e.responseStart - e.requestStart),
                                last_byte: Math.round(e.responseEnd - e.requestStart),
                                transfer_size: e.transferSize
                            }
                        }
                    } catch (e) {}
                    "pageview" === r.category && (a.firstPageview = !1), r.insert_id = o(), r = g(r), n("https://t.poki.io/t", JSON.stringify(r))
                } catch (e) {
                    t(e, "push")
                } else r()
            }
        }(q, J, e, (function() {
            for (var e = Math.floor(Date.now() / 1e3), t = "", a = 0; a < 4; a++) t = String.fromCharCode(255 & e) + t, e >>= 8;
            if (window.crypto && crypto.getRandomValues && Uint32Array) {
                var n = new Uint32Array(12);
                crypto.getRandomValues(n);
                for (var o = 0; o < 12; o++) t += String.fromCharCode(255 & n[o])
            } else
                for (var i = 0; i < 12; i++) t += String.fromCharCode(Math.floor(256 * Math.random()));
            return btoa(t).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "")
        }), l, (function() {
            return s
        })); J.length > 0;) J.push(J.shift());
    ! function() {
        for (window.pokiGTM = window.pokiGTM || [], window.pokiGTM.push = x, window.pokiGTM.push({
                event: "pageview",
                eventData: {}
            }); window.pokiGTM.length > 0;) window.pokiGTM.push(window.pokiGTM.shift())
    }()
}();